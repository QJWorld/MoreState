//
//  ViewController.m
//  JAAlertViewDemo
//
//  Created by QIUJUN on 2017/7/12.
//  Copyright © 2017年 QIUJUN. All rights reserved.
//
// JAAlertViewDemo
#import "ViewController.h"
#import "JAAlertView.h"
#import "TwoVC.h"
// 定义按钮 回调block 函数
typedef void (^JAAction)();

@interface ViewController ()
// 充当临时 强指针 使用 (系统会自动释放)
@property(nonatomic,strong) JAAlertView *currentAlert;
@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
}

- (IBAction)oneButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"去充值"];
    JAAlertView * currentAlert1 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"你的账户余额不足" ButtonsTitle:buttonsStr];
     _currentAlert = currentAlert1 ;
    currentAlert1.titleLabel.textColor = [UIColor redColor];
    currentAlert1.messageLabel.textColor = [UIColor orangeColor];
    UIButton *button0 = currentAlert1.btnsArray[0];
    [button0  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];

    [currentAlert1 show];
    
}

- (IBAction)twoButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"去充值",@"做任务"];
   JAAlertView * currentAlert2 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"你的账户余额不足" ButtonsTitle:buttonsStr];
     _currentAlert = currentAlert2 ;
    currentAlert2.titleLabel.textColor = [UIColor redColor];
    currentAlert2.messageLabel.textColor = [UIColor orangeColor];
    UIButton *button0 = currentAlert2.btnsArray[0];
    [button0  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];

    [currentAlert2 show];
}

- (IBAction)ThreeButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"去充值",@"做任务",@"找优惠",@"不管它"];
 JAAlertView * currentAlert3 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"你的账户余额不足" ButtonsTitle:buttonsStr];
    
    _currentAlert = currentAlert3 ;
    currentAlert3.jaAction = ^(NSInteger index){
        switch (index) {
            case 0:
                  NSLog(@"第0个按钮操作");
                break;
            case 1:
                  NSLog(@"第1个按钮操作");
                break;
                
            case 2:
                  NSLog(@"第2个按钮操作");
                break;
            case 3:
                  NSLog(@"第3个按钮操作");
                break;
                
            default:
                break;
        }
    };
    
    // 此处自定义,title,message,按钮颜色
    currentAlert3.titleLabel.textColor = [UIColor redColor];
    currentAlert3.messageLabel.textColor = [UIColor orangeColor];
    UIButton *button2 = currentAlert3.btnsArray[2];
    [button2  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];

    [currentAlert3 show];

    
    
}



- (IBAction)systemAlert:(id)sender {
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了确定");
    }];
    
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了取消");
    }];
    
    UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"不知道" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了不知道");
    }];
    
    UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"温馨提醒" message:@"我是系统弹框" preferredStyle: UIAlertControllerStyleAlert];
    
    [alertController addAction:action1];
    [alertController addAction:action2];
    [alertController addAction:action3];
    [self showViewController:alertController sender:nil];
    
}

- (IBAction)jumpToNextView:(id)sender {
     TwoVC *twoVC = [[TwoVC alloc] init];
    [self presentViewController:twoVC animated:YES completion:nil];
    
}


// 此处 也可以省略 (系统会自动释放)
-(void)viewDidDisappear:(BOOL)animated {
    _currentAlert = nil ; // 释放掉 对弹框的强引用, 将指针置空,防止出现也指针错误

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
