//
//  ViewController.m
//  JAAlertViewDemo
//
//  Created by QIUJUN on 2017/7/12.
//  Copyright © 2017年 QIUJUN. All rights reserved.
//
// JAAlertViewDemo
#import "ViewController.h"
#import "JAAlertView.h"
#import "TwoVC.h"
// 定义按钮 回调block 函数
typedef void (^JAAction)();

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

// 没有按钮 弹框
- (IBAction)NOButtonAlert:(id)sender {
    JAAlertView *currentAlert0 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"下一个新版本本地模式将取消,请在登录模式下同步数据" ButtonsTitle:nil];
    currentAlert0.titleLabel.textColor = [UIColor redColor];
    currentAlert0.messageLabel.textColor = [UIColor orangeColor];
    [currentAlert0 show];
    
}


// 1个 按钮, 没有 实现按钮回调操作 (可以不实现,内部会默认退出弹框)
- (IBAction)oneButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"去充值"];
    JAAlertView *currentAlert1 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"你的账户余额不足" ButtonsTitle:buttonsStr];
    currentAlert1.titleLabel.textColor = [UIColor redColor];
    currentAlert1.messageLabel.textColor = [UIColor orangeColor];
    UIButton *button0 = currentAlert1.btnsArray[0];
    [button0  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    
    [currentAlert1 show];
    
}

// 2个 按钮, 没有 实现按钮回调操作 (可以不实现,内部会默认退出弹框)
- (IBAction)twoButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"取消",@"我知道了"];
   JAAlertView *currentAlert2 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"下一个新版本本地模式将取消\n,请在登录模式下同步数据\n100 是标题 和message 还有间隙的总高度 , 47是一个按钮高度100 是标题 和message 还有间隙的总高度 , 47是一个按钮高度100 是标题 和message 还有间隙的总高度 , 47是一个按钮高\n度" ButtonsTitle:buttonsStr];
    
    currentAlert2.titleLabel.textColor = [UIColor redColor];
    currentAlert2.messageLabel.textColor = [UIColor orangeColor];
    currentAlert2.messageLabel.textAlignment = NSTextAlignmentLeft;
    UIButton *button0 = currentAlert2.btnsArray[0];
    [button0  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [currentAlert2 show];
    
}


- (IBAction)ThreeButtonAlert:(id)sender {
    NSArray *buttonsStr = @[@"去充值",@"做任务",@"找优惠",@"不管它"];
  JAAlertView * currentAlert3 = [[JAAlertView alloc] jaAlertViewTitle:@"温馨提醒" Message:@"你的账户余额不足" ButtonsTitle:buttonsStr];
    // 根据需要 ,选择性 输入按钮的 回调操作 (可以不实现,内部会默认退出弹框)
    currentAlert3.jaAction = ^(NSInteger index){
        switch (index) {
            case 0:
                  NSLog(@"第0个按钮操作");
                break;
            case 1:
                  NSLog(@"第1个按钮操作");
                break;
                
            case 2:
                  NSLog(@"第2个按钮操作");
                break;
            case 3:
                  NSLog(@"第3个按钮操作");
                break;
                
            default:
                break;
        }
    };
    // 此处自定义,title,message,按钮颜色
    currentAlert3.titleLabel.textColor = [UIColor redColor];
    currentAlert3.messageLabel.textColor = [UIColor orangeColor];
    UIButton *button2 = currentAlert3.btnsArray[2];
    [button2  setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [currentAlert3 show];
    
}



//系统 弹框
- (IBAction)systemAlert:(id)sender {
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了确定");
    }];
    
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了取消");
    }];
    
    UIAlertAction *action3 = [UIAlertAction actionWithTitle:@"不知道" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了不知道");
    }];
    
    UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"温馨提醒" message:@"我是系统弹框" preferredStyle: UIAlertControllerStyleAlert];
    
    [alertController addAction:action1];
    [alertController addAction:action2];
    [alertController addAction:action3];
    [self showViewController:alertController sender:nil];
    
}

- (IBAction)jumpToNextView:(id)sender {
     TwoVC *twoVC = [[TwoVC alloc] init];
    [self presentViewController:twoVC animated:YES completion:nil];
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
