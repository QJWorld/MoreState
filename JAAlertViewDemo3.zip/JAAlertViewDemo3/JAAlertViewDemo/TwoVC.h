//
//  TwoVC.h
//  JAAlertViewDemo
//
//  Created by QIUJUN on 2017/7/14.
//  Copyright © 2017年 QIUJUN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwoVC : UIViewController

@end
